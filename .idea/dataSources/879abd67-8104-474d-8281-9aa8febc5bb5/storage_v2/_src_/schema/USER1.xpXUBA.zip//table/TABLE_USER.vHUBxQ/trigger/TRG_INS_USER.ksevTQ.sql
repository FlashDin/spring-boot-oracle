create trigger TRG_INS_USER
  before insert
  on TABLE_USER
  for each row
  begin
    select USER_SEQUENCE.nextval
    into :NEW.ID
    from dual;
  end;
/

